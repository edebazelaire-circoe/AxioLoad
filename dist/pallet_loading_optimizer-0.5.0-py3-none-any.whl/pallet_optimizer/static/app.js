const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const SETTINGS_STORAGE_KEY = 'axioload.settings.v1';
const DEFAULT_API_SERVICES = [
  {id:'routes', service:'Service d’itinéraires', purpose:'Préparation d’une future connexion à un calculateur de distances ou d’itinéraires.', key:''},
  {id:'maps', service:'Service cartographique', purpose:'Préparation d’une future connexion à un fond de carte ou à un service de géocodage.', key:''}
];
const state = { result: null, selected: 0, selectedVehicle: 0, angle: -0.72, tilt: 0.52, zoom: 1.45, hitAreas: [], drag: null, vehicles: window.PLO_VEHICLES || [], currentTab:'vehicles', lastMainTab:'vehicles' };

function clone(value){ return JSON.parse(JSON.stringify(value)); }
function loadAppSettings(){
  const defaults={theme:'light',account:{username:'Utilisateur AxioLoad',passwordHash:'',passwordSalt:''},apiKeys:clone(DEFAULT_API_SERVICES)};
  try{
    const saved=JSON.parse(localStorage.getItem(SETTINGS_STORAGE_KEY)||'{}');
    return {
      theme:saved.theme==='dark'?'dark':'light',
      account:{...defaults.account,...(saved.account||{})},
      apiKeys:Array.isArray(saved.apiKeys)?saved.apiKeys.map(entry=>({id:String(entry.id||`api_${Date.now()}`),service:String(entry.service||''),purpose:String(entry.purpose||''),key:String(entry.key||'')})):defaults.apiKeys
    };
  }catch(_){ return defaults; }
}
let appSettings=loadAppSettings();
function persistAppSettings(){ localStorage.setItem(SETTINGS_STORAGE_KEY,JSON.stringify(appSettings)); }
function showSettingsMessage(selector,message,error=false){
  const box=$(selector); if(!box)return; box.textContent=message; box.classList.toggle('hidden',!message); box.classList.toggle('error',Boolean(error)); box.classList.toggle('success',Boolean(message)&&!error);
}
function applyTheme(theme,{persist=false}={}){
  const normalized=theme==='dark'?'dark':'light';
  document.documentElement.dataset.theme=normalized;
  const meta=document.querySelector('meta[name="theme-color"]'); if(meta)meta.content=normalized==='dark'?'#0A202A':'#063B5B';
  $$('input[name="theme"]').forEach(input=>{input.checked=input.value===normalized;});
  if(persist){appSettings.theme=normalized;persistAppSettings();}
  if(state.result && typeof drawViewer==='function')drawViewer();
}

function switchTab(name) {
  if(name!=='settings')state.lastMainTab=name;
  state.currentTab=name;
  $$('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab === name));
  $$('.tab-panel').forEach(p => p.classList.toggle('active', p.id === `tab-${name}`));
  $('#open-settings')?.classList.toggle('active',name==='settings');
  if (name === 'history') loadHistory();
  if (name === 'vehicles') renderVehicleRows();
}
$$('.tab').forEach(button => button.addEventListener('click', () => switchTab(button.dataset.tab)));
$('#open-settings').addEventListener('click',()=>switchTab('settings'));
$('#close-settings').addEventListener('click',()=>switchTab(state.lastMainTab||'vehicles'));

const tooltip=$('#global-tooltip');
let pinnedHelp=null;
function positionTooltip(trigger){
  const rect=trigger.getBoundingClientRect(),gap=9;
  tooltip.style.left='0px';tooltip.style.top='0px';tooltip.hidden=false;
  const width=tooltip.offsetWidth,height=tooltip.offsetHeight;
  let left=Math.min(window.innerWidth-width-12,Math.max(12,rect.left+rect.width/2-width/2));
  let top=rect.bottom+gap;
  if(top+height>window.innerHeight-12)top=Math.max(12,rect.top-height-gap);
  tooltip.style.left=`${left}px`;tooltip.style.top=`${top}px`;
}
function showTooltip(trigger){
  if(!trigger?.dataset.tooltip)return;
  tooltip.textContent=trigger.dataset.tooltip;trigger.classList.add('open');positionTooltip(trigger);
}
function hideTooltip(trigger){
  if(trigger && pinnedHelp===trigger)return;
  trigger?.classList.remove('open');tooltip.hidden=true;
}
$$('.help-tip').forEach(trigger=>{
  trigger.addEventListener('mouseenter',()=>showTooltip(trigger));
  trigger.addEventListener('mouseleave',()=>hideTooltip(trigger));
  trigger.addEventListener('focus',()=>showTooltip(trigger));
  trigger.addEventListener('blur',()=>hideTooltip(trigger));
  trigger.addEventListener('click',event=>{
    event.preventDefault();event.stopPropagation();
    if(pinnedHelp===trigger){pinnedHelp=null;trigger.classList.remove('open');tooltip.hidden=true;return;}
    pinnedHelp?.classList.remove('open');pinnedHelp=trigger;showTooltip(trigger);
  });
});
document.addEventListener('click',()=>{if(pinnedHelp){pinnedHelp.classList.remove('open');pinnedHelp=null;tooltip.hidden=true;}});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&pinnedHelp){pinnedHelp.classList.remove('open');pinnedHelp=null;tooltip.hidden=true;}});
window.addEventListener('resize',()=>{if(pinnedHelp)positionTooltip(pinnedHelp);else tooltip.hidden=true;});
window.addEventListener('scroll',()=>{if(pinnedHelp)positionTooltip(pinnedHelp);else tooltip.hidden=true;},{passive:true});

function bytesToHex(bytes){return [...new Uint8Array(bytes)].map(byte=>byte.toString(16).padStart(2,'0')).join('');}
function randomSalt(){
  if(window.crypto?.getRandomValues){const bytes=new Uint8Array(16);window.crypto.getRandomValues(bytes);return bytesToHex(bytes);}
  return `${Date.now()}_${Math.random().toString(36).slice(2)}`;
}
async function hashPassword(password,salt){
  const value=`${salt}:${password}`;
  if(window.crypto?.subtle){return bytesToHex(await window.crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)));}
  let hash=2166136261;for(let index=0;index<value.length;index++){hash^=value.charCodeAt(index);hash=Math.imul(hash,16777619);}return `fallback_${(hash>>>0).toString(16)}`;
}
function renderAccountSettings(){
  $('#current-username').value=appSettings.account.username||'Utilisateur AxioLoad';
  $('#new-username').value=appSettings.account.username||'Utilisateur AxioLoad';
}
$('#account-form').addEventListener('submit',async event=>{
  event.preventDefault();showSettingsMessage('#account-message','');
  const username=$('#new-username').value.trim(),current=$('#current-password').value,newPassword=$('#new-password').value,confirmation=$('#confirm-password').value;
  try{
    if(!username)throw new Error('Le nom d’utilisateur ne peut pas être vide.');
    if(appSettings.account.passwordHash){
      const currentHash=await hashPassword(current,appSettings.account.passwordSalt);
      if(currentHash!==appSettings.account.passwordHash)throw new Error('Le mot de passe actuel est incorrect.');
    }
    if(newPassword||confirmation){
      if(newPassword.length<8)throw new Error('Le nouveau mot de passe doit contenir au moins 8 caractères.');
      if(newPassword!==confirmation)throw new Error('La confirmation ne correspond pas au nouveau mot de passe.');
      const salt=randomSalt();appSettings.account.passwordSalt=salt;appSettings.account.passwordHash=await hashPassword(newPassword,salt);
    }
    appSettings.account.username=username;persistAppSettings();renderAccountSettings();
    $('#current-password').value='';$('#new-password').value='';$('#confirm-password').value='';
    showSettingsMessage('#account-message','Les informations du compte local ont été enregistrées.');
  }catch(error){showSettingsMessage('#account-message',error.message||String(error),true);}
});
$$('.password-toggle').forEach(button=>button.addEventListener('click',()=>{
  const input=$(`#${button.dataset.target}`),show=input.type==='password';input.type=show?'text':'password';button.textContent=show?'Masquer':'Afficher';button.setAttribute('aria-label',`${show?'Masquer':'Afficher'} le mot de passe`);
}));
$$('input[name="theme"]').forEach(input=>input.addEventListener('change',()=>applyTheme(input.value,{persist:true})));
$('#save-appearance').addEventListener('click',()=>{
  const selected=$('input[name="theme"]:checked')?.value||'light';applyTheme(selected,{persist:true});showSettingsMessage('#appearance-message',`Le mode ${selected==='dark'?'sombre':'clair'} est enregistré.`);
});
function escapeHtml(value){return String(value).replace(/[&<>'"]/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));}
function newApiKeyEntry(){return {id:`api_${Date.now()}_${Math.random().toString(36).slice(2,7)}`,service:'Nouveau service',purpose:'Décrivez ici le rôle prévu de cette future connexion.',key:''};}
function renderApiKeys(){
  const list=$('#api-key-list');list.innerHTML='';
  if(!appSettings.apiKeys.length){list.innerHTML='<div class="api-empty">Aucun service préparé. Utilisez « Ajouter un service » pour créer une ligne.</div>';return;}
  appSettings.apiKeys.forEach(entry=>{
    const row=document.createElement('div');row.className='api-key-row';row.dataset.id=entry.id;
    row.innerHTML=`<div class="api-key-fields"><label>Nom du service<input data-api="service" value="${escapeHtml(entry.service)}" maxlength="100"></label><label>Rôle prévu<input data-api="purpose" value="${escapeHtml(entry.purpose)}" maxlength="220"></label><label>Clé API<span class="password-field"><input data-api="key" type="password" value="${escapeHtml(entry.key)}" autocomplete="off" placeholder="Clé confidentielle"><button type="button" class="api-key-toggle password-toggle">Afficher</button></span></label></div><div class="api-key-actions"><button type="button" class="secondary small api-save">Enregistrer</button><button type="button" class="row-delete api-delete">Supprimer</button></div>`;
    row.querySelector('.api-key-toggle').addEventListener('click',event=>{const input=row.querySelector('[data-api="key"]'),show=input.type==='password';input.type=show?'text':'password';event.currentTarget.textContent=show?'Masquer':'Afficher';});
    row.querySelector('.api-save').addEventListener('click',()=>{
      const service=row.querySelector('[data-api="service"]').value.trim(),purpose=row.querySelector('[data-api="purpose"]').value.trim(),key=row.querySelector('[data-api="key"]').value;
      if(!service)return showSettingsMessage('#api-message','Indiquez le nom du service avant d’enregistrer.',true);
      const target=appSettings.apiKeys.find(item=>item.id===entry.id);Object.assign(target,{service,purpose,key});persistAppSettings();showSettingsMessage('#api-message',`La clé de « ${service} » est enregistrée localement. Elle n’est utilisée par aucun calcul.`);
    });
    row.querySelector('.api-delete').addEventListener('click',()=>{
      if(!confirm(`Supprimer la clé préparatoire « ${entry.service} » ?`))return;
      appSettings.apiKeys=appSettings.apiKeys.filter(item=>item.id!==entry.id);persistAppSettings();renderApiKeys();showSettingsMessage('#api-message','Le service et sa clé locale ont été supprimés.');
    });
    list.append(row);
  });
}
$('#add-api-key').addEventListener('click',()=>{appSettings.apiKeys.push(newApiKeyEntry());persistAppSettings();renderApiKeys();});
applyTheme(appSettings.theme);
renderAccountSettings();
renderApiKeys();

const vehicleFields = ['model_id','name','interior_length_mm','interior_width_mm','interior_height_mm','linear_meter_width_mm','payload_kg','door_width_mm','door_height_mm'];
function vehicleRowTemplate(vehicle = {}) {
  const tr = document.createElement('tr');
  const exists = Boolean(vehicle.version);
  tr.dataset.original = JSON.stringify(vehicle);
  tr.innerHTML = `
    <td><input data-v="model_id" value="${vehicle.model_id ?? `vehicle_${Date.now()}`}" ${exists?'readonly':''}></td>
    <td><input data-v="name" value="${vehicle.name ?? 'Nouveau véhicule'}"></td>
    <td><input data-v="interior_length_mm" type="number" min="1" value="${vehicle.interior_length_mm ?? 6000}"></td>
    <td><input data-v="interior_width_mm" type="number" min="1" value="${vehicle.interior_width_mm ?? 2400}"></td>
    <td><input data-v="interior_height_mm" type="number" min="1" value="${vehicle.interior_height_mm ?? 2500}"></td>
    <td><input data-v="linear_meter_width_mm" type="number" min="1" value="${vehicle.linear_meter_width_mm ?? 2400}"></td>
    <td><input data-v="payload_kg" type="number" min="1" step="0.1" value="${vehicle.payload_kg ?? 10000}"></td>
    <td><input data-v="door_width_mm" type="number" min="1" value="${vehicle.door_width_mm ?? vehicle.interior_width_mm ?? 2400}"></td>
    <td><input data-v="door_height_mm" type="number" min="1" value="${vehicle.door_height_mm ?? vehicle.interior_height_mm ?? 2500}"></td>
    <td><span class="version-badge">v${vehicle.version ?? 'nouvelle'}</span></td>
    <td><button class="row-delete vehicle-delete" title="Supprimer">×</button></td>`;
  tr.querySelector('.vehicle-delete').addEventListener('click', async () => {
    const modelId = tr.querySelector('[data-v="model_id"]').value.trim();
    if (!exists) { tr.remove(); return; }
    if (!confirm(`Supprimer le véhicule ${modelId} ?`)) return;
    const response = await fetch(`/api/vehicles/${encodeURIComponent(modelId)}`, {method:'DELETE', headers:{'X-Tenant-ID':'demo'}});
    if (!response.ok) { const body=await response.json(); return showVehicleMessage(body.detail || 'Suppression impossible', true); }
    await loadVehicles(); showVehicleMessage('Véhicule supprimé.');
  });
  return tr;
}
function renderVehicleRows() {
  const tbody = $('#vehicle-table tbody');
  if (!tbody) return;
  tbody.innerHTML = '';
  state.vehicles.forEach(vehicle => tbody.append(vehicleRowTemplate(vehicle)));
}
function vehicleRowData(row) {
  const original = JSON.parse(row.dataset.original || '{}');
  const payload = {...original};
  row.querySelectorAll('[data-v]').forEach(input => {
    payload[input.dataset.v] = input.type === 'number' ? Number(input.value) : input.value.trim();
  });
  return payload;
}
function showVehicleMessage(message, error=false) {
  const box=$('#vehicle-message'); box.textContent=message; box.classList.toggle('hidden',!message);
  box.classList.toggle('error',error); box.classList.toggle('success',!error);
}
function refreshVehicleSelect(preferred) {
  const select=$('#vehicle-id'); if(!select)return;
  const selected=preferred || select.value || state.vehicles[0]?.model_id;
  select.innerHTML=state.vehicles.map(v=>`<option value="${v.model_id}" ${v.model_id===selected?'selected':''}>${v.name}</option>`).join('');
  if (!select.value && state.vehicles.length) select.value=state.vehicles[0].model_id;
  window.PLO_VEHICLES=state.vehicles;
  updateSelectedVehicleSummary();
}
function updateSelectedVehicleSummary(){
  const vehicle=state.vehicles.find(v=>v.model_id===$('#vehicle-id')?.value);
  const box=$('#selected-vehicle-summary'); if(!box)return;
  box.innerHTML=vehicle ? `<strong>${vehicle.name}</strong><span>${fmt(vehicle.interior_length_mm/1000,2)} × ${fmt(vehicle.interior_width_mm/1000,2)} × ${fmt(vehicle.interior_height_mm/1000,2)} m intérieurs · charge utile ${fmt(vehicle.payload_kg,0)} kg · version ${vehicle.version}</span>` : '';
}
async function loadVehicles(){
  const response=await fetch('/api/vehicles',{headers:{'X-Tenant-ID':'demo'}});
  if(!response.ok)throw new Error('Impossible de charger le catalogue véhicules.');
  const preferred=$('#vehicle-id')?.value;
  state.vehicles=await response.json(); renderVehicleRows(); refreshVehicleSelect(preferred);
}
$('#add-vehicle').addEventListener('click',()=>$('#vehicle-table tbody').append(vehicleRowTemplate()));
$('#save-vehicles').addEventListener('click',async()=>{
  showVehicleMessage('');
  try{
    const rows=$$('#vehicle-table tbody tr');
    if(!rows.length)throw new Error('Ajoutez au moins un véhicule.');
    for(const row of rows){
      const payload=vehicleRowData(row);
      const response=await fetch('/api/vehicles',{method:'POST',headers:{'Content-Type':'application/json','X-Tenant-ID':'demo'},body:JSON.stringify(payload)});
      const body=await response.json();
      if(!response.ok)throw new Error(body.detail?.message || body.detail || `Erreur sur ${payload.model_id}`);
    }
    await loadVehicles(); showVehicleMessage('Catalogue enregistré. Les nouvelles dimensions seront utilisées au prochain calcul.');
  }catch(error){showVehicleMessage(error.message||String(error),true);}
});
$('#reset-vehicles').addEventListener('click',async()=>{
  if(!confirm('Restaurer les deux véhicules de démonstration et supprimer les véhicules personnalisés ?'))return;
  const response=await fetch('/api/vehicles/reset-defaults',{method:'POST',headers:{'X-Tenant-ID':'demo'}});
  if(!response.ok)return showVehicleMessage('Restauration impossible.',true);
  state.vehicles=await response.json();renderVehicleRows();refreshVehicleSelect();showVehicleMessage('Modèles de démonstration restaurés.');
});
$('#vehicle-id').addEventListener('change',updateSelectedVehicleSummary);
renderVehicleRows(); refreshVehicleSelect();

function rowTemplate(item = {}) {
  const tr = document.createElement('tr');
  const order = item.delivery_order ?? ($('#cargo-table tbody').children.length + 1);
  tr.draggable = true;
  tr.innerHTML = `
    <td class="drag-handle" title="Glisser pour réordonner">⋮⋮</td>
    <td><input data-k="id" value="${item.id ?? `PAL-${String(order).padStart(3,'0')}`}"></td>
    <td><input data-k="quantity" type="number" min="1" value="${item.quantity ?? 1}"></td>
    <td><select data-k="shape">${['pallet','box','roll','cylinder','sheet','post','bar_rect','bar_cyl'].map(v => `<option ${item.shape===v?'selected':''}>${v}</option>`).join('')}</select></td>
    <td><input data-k="length" type="number" min="1" value="${item.length ?? 1200}"></td>
    <td><input data-k="width" type="number" min="1" value="${item.width ?? 800}"></td>
    <td><input data-k="height" type="number" min="1" value="${item.height ?? 1200}"></td>
    <td><input data-k="weight" type="number" min="0.1" step="0.1" value="${item.weight ?? 500}"></td>
    <td><input data-k="destination" value="${item.destination ?? `Client ${order}`}"></td>
    <td><input data-k="delivery_order" type="number" min="0" value="${order}"></td>
    <td><input data-k="rotation_allowed" type="checkbox" ${item.rotation_allowed === false || ['non','false','0'].includes(String(item.rotation_allowed).toLowerCase()) ? '' : 'checked'}></td>
    <td><input data-k="keep_together_group" value="${item.keep_together_group ?? ''}" placeholder="G1"></td>
    <td><input data-k="separate_group" value="${item.separate_group ?? ''}" placeholder="S1"></td>
    <td><input data-k="compatibility_tags" value="${Array.isArray(item.compatibility_tags)?item.compatibility_tags.join(','):item.compatibility_tags ?? ''}" placeholder="alimentaire"></td>
    <td><input data-k="incompatible_tags" value="${Array.isArray(item.incompatible_tags)?item.incompatible_tags.join(','):item.incompatible_tags ?? ''}" placeholder="chimique"></td>
    <td><input data-k="separation" type="number" min="0" value="${item.separation ?? 0}"></td>
    <td><button class="row-delete" title="Supprimer">×</button></td>`;
  tr.querySelector('.row-delete').addEventListener('click', () => tr.remove());
  tr.addEventListener('dragstart', () => tr.classList.add('dragging'));
  tr.addEventListener('dragend', () => { tr.classList.remove('dragging'); renumberDefaultOrders(); });
  return tr;
}
function addRow(item) { $('#cargo-table tbody').append(rowTemplate(item)); }
$('#cargo-table tbody').addEventListener('dragover', event => {
  event.preventDefault();
  const dragging = $('#cargo-table tbody tr.dragging'); if (!dragging) return;
  const siblings = $$('#cargo-table tbody tr:not(.dragging)');
  const next = siblings.find(row => event.clientY <= row.getBoundingClientRect().top + row.offsetHeight / 2);
  $('#cargo-table tbody').insertBefore(dragging, next || null);
});
function renumberDefaultOrders(){ $$('#cargo-table tbody tr').forEach((row,index)=>{ const input=row.querySelector('[data-k="delivery_order"]'); if(input && !input.dataset.manual) input.value=index+1; }); }
$('#cargo-table tbody').addEventListener('input', event => { if(event.target.matches('[data-k="delivery_order"]')) event.target.dataset.manual='1'; });
addRow({id:'PAL-001',destination:'Client A',delivery_order:1});
addRow({id:'PAL-002',destination:'Client B',delivery_order:2,width:1000,weight:600});
$('#add-row').addEventListener('click', () => addRow());
$('#duplicate-row').addEventListener('click', () => {
  const last = $('#cargo-table tbody tr:last-child');
  if (!last) return addRow();
  const item = rowData(last); item.id = `${item.id}-COPY`; addRow(item);
});
function rowData(row) {
  const item = {};
  row.querySelectorAll('[data-k]').forEach(input => {
    const k = input.dataset.k;
    item[k] = input.type === 'checkbox' ? input.checked : (input.type === 'number' ? Number(input.value) : input.value.trim());
  });
  return item;
}
function buildPayload() {
  return {
    dimension_unit: 'mm', weight_unit: 'kg', seed: Number($('#seed').value),
    default_margins: {left:Number($('#default-margin').value),right:Number($('#default-margin').value),front:Number($('#default-margin').value),rear:Number($('#default-margin').value),top:0},
    budget_seconds: Number($('#budget-seconds').value), requested_solutions: 5,
    vehicle_policy: {mode:'forced', forced_vehicle_id:$('#vehicle-id').value, max_vehicles:Number($('#max-vehicles').value)},
    items: $$('#cargo-table tbody tr').map(rowData)
  };
}
function showError(message) { const box=$('#data-errors'); box.textContent=message; box.classList.toggle('hidden',!message); }

$('#optimize').addEventListener('click', async () => {
  showError(''); const button=$('#optimize'); button.disabled=true; button.textContent='Calcul en cours…';
  try {
    const response = await fetch('/local/optimize',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(buildPayload())});
    const result = await response.json();
    state.result=result; state.selected=0; state.selectedVehicle=0;
    if (!result.solutions?.length) {
      const diagnostics=(result.diagnostics||[]).map(d=>`${d.message}`).join('\n');
      throw new Error(diagnostics || 'Le moteur n’a retourné aucun plan. Consultez les dimensions du véhicule et les contraintes saisies.');
    }
    renderResults(); switchTab('results');
  } catch (error) { showError(error.message || String(error)); }
  finally { button.disabled=false; button.textContent='Optimiser le chargement'; }
});

$('#import-file').addEventListener('change', async event => {
  const file=event.target.files[0]; if(!file)return;
  const data=new FormData(); data.append('file',file);
  try{
    const response=await fetch(`/api/import/preview?vehicle_id=${encodeURIComponent($('#vehicle-id').value)}`,{method:'POST',body:data});
    const body=await response.json(); if(!response.ok)throw new Error(body.detail?.message||body.detail||'Import invalide');
    $('#cargo-table tbody').innerHTML=''; body.payload.items.forEach(addRow); showError('');
  }catch(error){showError(error.message||String(error));}
});

function fmt(value,digits=2){return Number(value).toLocaleString('fr-FR',{maximumFractionDigits:digits,minimumFractionDigits:digits});}
function planMetricsFromPlacements(plan){
  const occupiedMm=Math.max(0,...(plan.placements||[]).map(p=>p.y_mm+p.envelope_length_mm));
  const occupiedM=occupiedMm/1000;
  return {occupiedMm,occupiedM,linearMeters:occupiedM};
}
function solutionConsistencyDiagnostics(solution){
  const diagnostics=[];
  let occupiedTotal=0,linearTotal=0;
  solution.vehicle_plans.forEach((plan,index)=>{
    const calculated=planMetricsFromPlacements(plan);
    occupiedTotal+=calculated.occupiedM; linearTotal+=calculated.linearMeters;
    if(Math.abs(Number(plan.occupied_length_m)-calculated.occupiedM)>1e-6 || Math.abs(Number(plan.linear_meters)-calculated.linearMeters)>1e-6){
      diagnostics.push({severity:'error',code:'METRIC_DATA_MISMATCH',message:`Le véhicule ${index+1} présente une incohérence entre ses positions, sa longueur occupée et ses mètres linéaires.`});
    }
  });
  if(Math.abs(Number(solution.occupied_length_m)-occupiedTotal)>1e-6 || Math.abs(Number(solution.total_linear_meters)-linearTotal)>1e-6){
    diagnostics.push({severity:'error',code:'SOLUTION_METRIC_MISMATCH',message:'Les totaux de la solution ne correspondent pas à la somme des plans véhicules.'});
  }
  return diagnostics;
}
function renderResults(){
  $('#empty-results').classList.add('hidden'); $('#results-content').classList.remove('hidden');
  $('#run-meta').textContent=`${state.result.status} · ${fmt(state.result.elapsed_seconds,3)} s · graine ${state.result.seed}`;
  const cards=$('#solution-cards'); cards.innerHTML='';
  state.result.solutions.forEach((solution,index)=>{
    const card=document.createElement('button'); card.className=`solution-card ${index===0?'recommended':''} ${index===state.selected?'active':''}`;
    card.innerHTML=`<h3>Solution ${solution.rank}</h3><div class="metric-big">${fmt(solution.total_linear_meters)} <span>m.l.</span></div><div class="metric-row"><span>Véhicules</span><strong>${solution.vehicle_count}</strong></div><div class="metric-row"><span>Longueur réellement occupée</span><strong>${fmt(solution.occupied_length_m)} m</strong></div>`;
    card.addEventListener('click',()=>{state.selected=index;state.selectedVehicle=0;renderResults();}); cards.append(card);
  });
  const solution=state.result.solutions[state.selected];
  if (state.selectedVehicle >= solution.vehicle_plans.length) state.selectedVehicle = 0;
  const vehicleSelect=$('#viewer-vehicle'); vehicleSelect.innerHTML=solution.vehicle_plans.map((plan,index)=>`<option value="${index}" ${index===state.selectedVehicle?'selected':''}>Véhicule ${index+1}</option>`).join('');
  vehicleSelect.classList.toggle('hidden', solution.vehicle_plans.length===1);
  const plan=solution.vehicle_plans[state.selectedVehicle],vehicle=vehicleFor(plan),metrics=planMetricsFromPlacements(plan);
  $('#viewer-title').textContent=`Solution ${solution.rank} · ${plan.vehicle_name}`;
  $('#viewer-subtitle').textContent=`Longueur occupée ${fmt(metrics.occupiedM)} m · ${fmt(metrics.linearMeters)} m.l. · véhicule ${fmt(vehicle.interior_length_mm/1000)} × ${fmt(vehicle.interior_width_mm/1000)} × ${fmt(vehicle.interior_height_mm/1000)} m`;
  const diagnostics=[...(state.result.diagnostics||[]),...(solution.diagnostics||[]),...solution.vehicle_plans.flatMap(p=>p.diagnostics||[]),...solutionConsistencyDiagnostics(solution)];
  $('#diagnostics').innerHTML=diagnostics.length?diagnostics.map(d=>`<div class="diagnostic ${d.severity}"><strong>${d.code}</strong><br>${d.message}</div>`).join(''):'<div class="diagnostic">Aucune anomalie bloquante.</div>';
  const run=state.result.run_id;
  $('#exports').innerHTML=`<a href="/api/history/${run}/export.xlsx" target="_blank">XLSX</a><a href="/api/history/${run}/export.csv" target="_blank">CSV</a><a href="/api/history/${run}/export.json" target="_blank">JSON</a><a href="#" id="export-png">PNG haute définition</a><a href="#" id="export-operational-pdf" class="operational-export">PDF opérationnel avec vue 3D</a>`;
  $('#export-png').addEventListener('click',event=>{event.preventDefault();downloadDataUrl(renderSceneDataUrl(),`axioload-plan-${run}-solution-${solution.rank}.png`);});
  $('#export-operational-pdf').addEventListener('click',exportOperationalPdf);
  $('#inspection').textContent='Cliquez sur un objet dans la scène.'; drawViewer();
}

const canvas=$('#viewer'), ctx=canvas.getContext('2d');
function vehicleFor(plan){return state.vehicles.find(v=>`${v.model_id}@${v.version}`===plan.vehicle_version_id)||state.vehicles.find(v=>v.model_id===plan.vehicle_version_id.split('@')[0])||state.vehicles[0];}
function projectWorld(longitudinal,width,height,origin,scale,view=state){
  const ca=Math.cos(view.angle),sa=Math.sin(view.angle),ct=Math.cos(view.tilt),st=Math.sin(view.tilt);
  const rx=longitudinal*ca-width*sa, ry=longitudinal*sa+width*ca;
  return [origin[0]+rx*scale,origin[1]+(ry*st-height*ct)*scale];
}
function polygon(target,points,fill,stroke='#183B4D',lineWidth=1){target.beginPath();points.forEach((p,i)=>i?target.lineTo(...p):target.moveTo(...p));target.closePath();if(fill){target.fillStyle=fill;target.fill();}target.strokeStyle=stroke;target.lineWidth=lineWidth;target.stroke();}
function line(target,a,b,color,width=1,dash=[]){target.save();target.beginPath();target.moveTo(...a);target.lineTo(...b);target.strokeStyle=color;target.lineWidth=width;target.setLineDash(dash);target.stroke();target.restore();}
function screenLabel(target,text,x,y,options={}){
  const font=options.font||'700 12px Segoe UI, Arial, sans-serif'; target.save();target.font=font;target.textAlign=options.align||'center';target.textBaseline='middle';
  const metrics=target.measureText(text),paddingX=options.paddingX??6,paddingY=options.paddingY??4,fontSize=Number(font.match(/([0-9.]+)px/)?.[1]||12),h=fontSize+paddingY*2,w=metrics.width+paddingX*2;
  const left=target.textAlign==='center'?x-w/2:(target.textAlign==='right'?x-w:x);
  target.fillStyle=options.background||'rgba(255,255,255,.90)';target.strokeStyle=options.border||'rgba(6,59,91,.25)';target.lineWidth=1;
  target.beginPath();target.roundRect(left,y-h/2,w,h,5);target.fill();target.stroke();target.fillStyle=options.color||'#063B5B';target.fillText(text,x,y+0.5);target.restore();
}
function paletteColor(index){const colors=['#00A8BF','#16B8B0','#A6DE75','#4B8FC4','#F19B5C','#9A78C2','#E66B82'];return colors[index%colors.length];}
function drawArrowHead(target,from,to,color){const angle=Math.atan2(to[1]-from[1],to[0]-from[0]),size=7;target.save();target.fillStyle=color;target.beginPath();target.moveTo(to[0],to[1]);target.lineTo(to[0]-size*Math.cos(angle-.45),to[1]-size*Math.sin(angle-.45));target.lineTo(to[0]-size*Math.cos(angle+.45),to[1]-size*Math.sin(angle+.45));target.closePath();target.fill();target.restore();}
function drawDimension(target,startWorld,endWorld,label,color,origin,scale,view,labelTheme={}){
  const a=projectWorld(...startWorld,origin,scale,view),b=projectWorld(...endWorld,origin,scale,view);line(target,a,b,color,2);drawArrowHead(target,b,a,color);drawArrowHead(target,a,b,color);screenLabel(target,label,(a[0]+b[0])/2,(a[1]+b[1])/2-13,{color,border:color,background:labelTheme.labelBackground||'rgba(255,255,255,.94)'});
}
function drawGrid(target,vehicle,origin,scale,view,scene){
  const L=vehicle.interior_length_mm,W=vehicle.interior_width_mm,step=1000;
  for(let x=0;x<=L;x+=step){line(target,projectWorld(x,0,0,origin,scale,view),projectWorld(x,W,0,origin,scale,view),x%5000===0?scene.gridStrong:scene.grid,x%5000===0?1.4:.8);}
  for(let y=0;y<=W;y+=step){line(target,projectWorld(0,y,0,origin,scale,view),projectWorld(L,y,0,origin,scale,view),scene.gridWidth,.8);}
}
function sceneTheme(exportMode=false){
  const dark=document.documentElement.dataset.theme==='dark'&&!exportMode;
  return dark?{
    background:'#0B232D',floor:'#173945',floorStroke:'#6C98A8',frame:'#527988',topFrame:'rgba(113,158,172,.58)',
    gridStrong:'rgba(144,202,214,.30)',grid:'rgba(144,202,214,.14)',gridWidth:'rgba(34,198,192,.20)',
    labelBackground:'rgba(8,29,38,.94)',labelColor:'#EAF7F8',labelBorder:'rgba(116,184,199,.55)',metricBackground:'rgba(5,46,70,.96)'
  }:{
    background:'#F8FCFD',floor:'#ECF4F6',floorStroke:'#55798A',frame:'#7994A2',topFrame:'rgba(121,148,162,.55)',
    gridStrong:'rgba(6,59,91,.26)',grid:'rgba(6,59,91,.12)',gridWidth:'rgba(22,184,176,.16)',
    labelBackground:'rgba(255,255,255,.94)',labelColor:'#052E46',labelBorder:'rgba(6,59,91,.25)',metricBackground:'rgba(6,59,91,.92)'
  };
}
function drawScene(target,targetCanvas,{interactive=false,exportMode=false}={}){
  const solution=state.result?.solutions?.[state.selected]; if(!solution)return;
  const scene=sceneTheme(exportMode);target.clearRect(0,0,targetCanvas.width,targetCanvas.height);target.fillStyle=scene.background;target.fillRect(0,0,targetCanvas.width,targetCanvas.height);if(interactive)state.hitAreas=[];
  const plan=solution.vehicle_plans[state.selectedVehicle],vehicle=vehicleFor(plan),view=state;
  const max=Math.max(vehicle.interior_length_mm,vehicle.interior_width_mm,vehicle.interior_height_mm*1.7);
  const scale=(targetCanvas.width/1000)*420/max*view.zoom,origin=[targetCanvas.width*.45,targetCanvas.height*.76];
  const L=vehicle.interior_length_mm,W=vehicle.interior_width_mm,H=vehicle.interior_height_mm;
  const floor=[[0,0,0],[L,0,0],[L,W,0],[0,W,0]].map(p=>projectWorld(...p,origin,scale,view));polygon(target,floor,scene.floor,scene.floorStroke,1.2);drawGrid(target,vehicle,origin,scale,view,scene);
  [[[0,0,0],[0,0,H]],[[L,0,0],[L,0,H]],[[L,W,0],[L,W,H]],[[0,W,0],[0,W,H]]].forEach(pair=>line(target,projectWorld(...pair[0],origin,scale,view),projectWorld(...pair[1],origin,scale,view),scene.frame,1.2));
  const topFrame=[[0,0,H],[L,0,H],[L,W,H],[0,W,H],[0,0,H]].map(p=>projectWorld(...p,origin,scale,view));for(let i=0;i<topFrame.length-1;i++)line(target,topFrame[i],topFrame[i+1],scene.topFrame,1,[5,5]);
  vehicle.obstacles.forEach(o=>drawBox(target,{x_mm:o.x_mm,y_mm:o.y_mm,envelope_width_mm:o.width_mm,envelope_length_mm:o.length_mm,actual_height_mm:o.height_mm,item_id:o.id,destination:'Obstacle'},'#75838C',origin,scale,view,false,interactive));
  const sorted=[...plan.placements].sort((a,b)=>(a.y_mm+a.x_mm)-(b.y_mm+b.x_mm));
  sorted.forEach((p,i)=>drawBox(target,p,paletteColor(i),origin,scale,view,false,interactive));
  sorted.forEach((p,i)=>{
    const center=projectWorld(p.y_mm+p.envelope_length_mm/2,p.x_mm+p.envelope_width_mm/2,p.actual_height_mm,origin,scale,view);
    screenLabel(target,p.item_id,center[0]+((i%3)-1)*5,center[1]-10-(i%2)*14,{font:'800 11px Segoe UI, Arial, sans-serif',background:scene.labelBackground,color:scene.labelColor,border:scene.labelBorder});
  });
  drawDimension(target,[0,W+420,0],[L,W+420,0],`Longueur ${fmt(L/1000)} m`,'#00A8BF',origin,scale,view,scene);
  drawDimension(target,[-260,0,0],[-260,W,0],`Largeur ${fmt(W/1000)} m`,'#18A999',origin,scale,view,scene);
  drawDimension(target,[0,W+260,0],[0,W+260,H],`Hauteur ${fmt(H/1000)} m`,'#E83E5B',origin,scale,view,scene);
  const rear=projectWorld(0,W/2,0,origin,scale,view);screenLabel(target,'Porte arrière',rear[0],rear[1]+24,{font:'700 12px Segoe UI, Arial, sans-serif',background:scene.labelBackground,color:scene.labelColor,border:scene.labelBorder});
  const metrics=planMetricsFromPlacements(plan);screenLabel(target,`${fmt(metrics.occupiedM)} m occupés · ${fmt(metrics.linearMeters)} m.l.`,targetCanvas.width-18,24,{align:'right',font:exportMode?'800 18px Segoe UI, Arial, sans-serif':'800 13px Segoe UI, Arial, sans-serif',background:scene.metricBackground,color:'#FFFFFF',border:'#063B5B'});
}
function drawBox(target,p,color,origin,scale,view,showLabel,interactive){
  const longitudinal=p.y_mm,transverse=p.x_mm,length=p.envelope_length_mm,width=p.envelope_width_mm,height=p.actual_height_mm;
  const A=projectWorld(longitudinal,transverse,0,origin,scale,view),B=projectWorld(longitudinal+length,transverse,0,origin,scale,view),C=projectWorld(longitudinal+length,transverse+width,0,origin,scale,view),D=projectWorld(longitudinal,transverse+width,0,origin,scale,view);
  const E=projectWorld(longitudinal,transverse,height,origin,scale,view),F=projectWorld(longitudinal+length,transverse,height,origin,scale,view),G=projectWorld(longitudinal+length,transverse+width,height,origin,scale,view),H=projectWorld(longitudinal,transverse+width,height,origin,scale,view);
  polygon(target,[A,B,F,E],shade(color,-14));polygon(target,[B,C,G,F],shade(color,-28));polygon(target,[E,F,G,H],color,'#17465A',1);
  if(showLabel){const topCenter=projectWorld(longitudinal+length/2,transverse+width/2,height,origin,scale,view);screenLabel(target,p.item_id,topCenter[0],topCenter[1]-9,{font:'800 11px Segoe UI, Arial, sans-serif',background:'rgba(255,255,255,.92)',color:'#052E46'});}
  if(interactive){const points=[A,B,C,D,E,F,G,H],xs=points.map(q=>q[0]),ys=points.map(q=>q[1]);state.hitAreas.push({minX:Math.min(...xs),maxX:Math.max(...xs),minY:Math.min(...ys),maxY:Math.max(...ys),placement:p});}
}
function shade(hex,amount){const n=parseInt(hex.slice(1),16),r=Math.max(0,Math.min(255,(n>>16)+amount)),g=Math.max(0,Math.min(255,((n>>8)&255)+amount)),b=Math.max(0,Math.min(255,(n&255)+amount));return `rgb(${r},${g},${b})`;}
function drawViewer(){drawScene(ctx,canvas,{interactive:true});}
function renderSceneDataUrl(){const exportCanvas=document.createElement('canvas');exportCanvas.width=1800;exportCanvas.height=1100;const exportContext=exportCanvas.getContext('2d');drawScene(exportContext,exportCanvas,{interactive:false,exportMode:true});return exportCanvas.toDataURL('image/png',1);}
function downloadDataUrl(dataUrl,filename){const a=document.createElement('a');a.href=dataUrl;a.download=filename;document.body.append(a);a.click();a.remove();}
async function exportOperationalPdf(event){
  event.preventDefault();const link=event.currentTarget,run=state.result.run_id,solution=state.result.solutions[state.selected];link.textContent='Préparation du PDF…';link.style.pointerEvents='none';
  try{
    const plan=solution.vehicle_plans[state.selectedVehicle],vehicle=vehicleFor(plan),metrics=planMetricsFromPlacements(plan);
    const response=await fetch(`/api/history/${run}/export-operational.pdf`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
      image_data_url:renderSceneDataUrl(),solution_index:state.selected,vehicle_index:state.selectedVehicle,
      displayed_metrics:{occupied_length_m:metrics.occupiedM,linear_meters:metrics.linearMeters},
      vehicle_dimensions:{interior_length_mm:vehicle.interior_length_mm,interior_width_mm:vehicle.interior_width_mm,interior_height_mm:vehicle.interior_height_mm}
    })});
    if(!response.ok){const body=await response.json().catch(()=>({}));throw new Error(body.detail||'Export opérationnel impossible.');}
    const blob=await response.blob(),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`axioload-plan-${run}-solution-${solution.rank}.pdf`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }catch(error){alert(error.message||String(error));}
  finally{link.textContent='PDF opérationnel avec vue 3D';link.style.pointerEvents='';}
}
canvas.addEventListener('pointerdown',e=>{state.drag={x:e.clientX,y:e.clientY,angle:state.angle,tilt:state.tilt,moved:false};canvas.setPointerCapture(e.pointerId);});
canvas.addEventListener('pointermove',e=>{if(!state.drag)return;const dx=e.clientX-state.drag.x,dy=e.clientY-state.drag.y;if(Math.abs(dx)>3||Math.abs(dy)>3)state.drag.moved=true;state.angle=state.drag.angle+dx*.008;state.tilt=Math.max(.18,Math.min(1.15,state.drag.tilt-dy*.006));drawViewer();});
canvas.addEventListener('pointerup',e=>{if(!state.drag?.moved){const rect=canvas.getBoundingClientRect(),x=(e.clientX-rect.left)*canvas.width/rect.width,y=(e.clientY-rect.top)*canvas.height/rect.height;const hit=[...state.hitAreas].reverse().find(a=>x>=a.minX&&x<=a.maxX&&y>=a.minY&&y<=a.maxY);if(hit)inspect(hit.placement);}state.drag=null;});
canvas.addEventListener('pointercancel',()=>{state.drag=null;});
$('#reset-view').addEventListener('click',()=>{state.angle=-.72;state.tilt=.52;state.zoom=1.45;drawViewer();});
canvas.addEventListener('wheel',event=>{event.preventDefault();state.zoom=Math.max(.65,Math.min(4,state.zoom*(event.deltaY>0?.9:1.1)));drawViewer();},{passive:false});
$('#viewer-vehicle').addEventListener('change',event=>{state.selectedVehicle=Number(event.target.value);renderResults();});
function inspect(p){$('#inspection').innerHTML=`<div class="object-card"><strong>${p.item_id}</strong><br>${p.destination}<br><br>Position longitudinale: ${p.y_mm} mm<br>Position transversale: ${p.x_mm} mm<br>Hauteur de base: ${p.z_mm} mm<br>Dimensions L × l × H: ${p.actual_length_mm} × ${p.actual_width_mm} × ${p.actual_height_mm} mm<br>Orientation: ${p.orientation_deg}°<br>Poids: ${fmt(p.weight_kg,1)} kg<br>Ordre: ${p.delivery_order}</div>`;}

async function loadHistory(){
  const list=$('#history-list'); list.innerHTML='Chargement…';
  try{const response=await fetch('/api/history');const runs=await response.json();
    list.innerHTML=runs.length?'':'<div class="empty-state">Aucun calcul enregistré.</div>';
    runs.forEach(run=>{const div=document.createElement('div');div.className='history-item';div.innerHTML=`<div><strong>${run.id.slice(0,8)}</strong><br><small>${new Date(run.created_at).toLocaleString('fr-FR')}</small></div><span>${run.status}</span><span>${run.vehicle_count??'—'} véhicule(s)</span><span>${run.linear_meters==null?'—':fmt(run.linear_meters)+' m.l.'}</span><button data-action="open">Ouvrir</button><button data-action="duplicate">Dupliquer</button>`;div.querySelector('[data-action="open"]').addEventListener('click',()=>openRun(run.id));div.querySelector('[data-action="duplicate"]').addEventListener('click',()=>duplicateRun(run.id));list.append(div);});
  }catch(error){list.textContent=error.message;}
}
async function openRun(id){const response=await fetch(`/api/history/${id}`);const run=await response.json();state.result={...run.result,run_id:id};state.selected=0;state.selectedVehicle=0;renderResults();switchTab('results');}
$('#refresh-history').addEventListener('click',loadHistory);

async function duplicateRun(id){
  const response=await fetch(`/api/history/${id}`); const run=await response.json();
  const request=run.request; $('#cargo-table tbody').innerHTML=''; (request.items||[]).forEach(addRow);
  if(request.vehicle_policy?.forced_vehicle_id) $('#vehicle-id').value=request.vehicle_policy.forced_vehicle_id;
  if(request.budget_seconds) $('#budget-seconds').value=String(request.budget_seconds);
  if(request.seed!=null) $('#seed').value=request.seed;
  switchTab('data');
}
