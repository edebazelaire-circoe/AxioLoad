# AxioLoad

AxioLoad est un logiciel d’optimisation de chargement pour palettes, colis et marchandises non gerbables. Le moteur recherche plusieurs plans à l’aide d’un portefeuille MaxRects et points extrêmes, minimise d’abord le nombre de véhicules puis la longueur réellement occupée, et contrôle la géométrie, les ouvertures, les obstacles, le poids, les essieux, le LIFO et les incompatibilités.

## Nouveautés de la version 0.4.0

- identité visuelle AxioLoad et palette inspirée de l’univers graphique de CIRCOE;
- logos Web en SVG et PNG, versions horizontale, compacte et icône/favicone;
- repère 3D unifié: longueur dans le sens longitudinal, largeur dans le sens transversal, hauteur verticale;
- références des marchandises affichées dans la scène;
- dimensions du véhicule et grille métrique intégrées au visuel;
- rotation et inclinaison de la vue par glisser, zoom à la molette;
- export PNG haute définition et PDF opérationnel intégrant la capture 3D;
- mètres linéaires calculés individuellement à partir de la longueur réellement occupée par chaque plan.

Le champ historique `linear_meter_width_mm` est conservé dans le catalogue pour préserver la compatibilité des données et des API. Il n’est plus utilisé pour la valeur affichée en « m.l. », conformément à la règle demandée dans cette version.

## Catalogue véhicules

L’onglet **0. Véhicules** permet de créer ou modifier:

- longueur, largeur et hauteur intérieures;
- largeur de référence historique LDM;
- charge utile;
- largeur et hauteur de l’ouverture arrière.

Chaque modification crée une nouvelle version et les calculs suivants utilisent immédiatement les dimensions enregistrées. Aucune clé API n’est requise pour l’interface locale.

## Démarrage local

```bash
python -m pip install -e '.[dev]' --no-build-isolation
pallet-optimizer --data-dir data serve --host 127.0.0.1 --port 8000
```

Ouvrir ensuite `http://127.0.0.1:8000`.

## Déploiement Docker

```bash
docker compose down
docker compose build --no-cache
docker compose up -d --force-recreate
```

Ne pas utiliser `docker compose down -v`, afin de conserver le volume de données.

## API facultative

Les clés API concernent uniquement l’intégration externe `POST /v1/optimizations`. L’interface, les véhicules, les imports, l’historique et les exports locaux n’en demandent aucune.

## Tests

```bash
pytest
PYTHONPATH=src python scripts/smoke_test.py
PYTHONPATH=src python scripts/ui_e2e.py
```

La recette couvre les moteurs d’optimisation, les dimensions véhicule, les cinq solutions, les mètres linéaires par plan, les imports CSV/XLSX, les exports, le PDF avec capture 3D, la navigation, l’affichage ordinateur/mobile, l’absence d’erreurs JavaScript et la persistance des données.

## Retour à la version précédente

Le ZIP d’origine de la V3 est conservé dans `rollback/pallet_loading_optimizer_v3_original.zip`. La procédure détaillée figure dans `reports/final-implementation-report-v4.md`.

## Limites explicites

- aucun gerbage ni modification manuelle des placements dans la scène;
- modèle d’essieux simplifié à valider selon le véhicule réel;
- recherche heuristique déterministe, sans garantie d’optimalité mathématique;
- les versions historiques d’un véhicule sont référencées dans les résultats, mais le catalogue conserve uniquement sa dernière définition active.
