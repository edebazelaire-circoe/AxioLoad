"""Pallet Loading Optimizer."""

__version__ = "0.3.0"
