"""AxioLoad transport loading optimizer."""

__version__ = "0.8.0"
