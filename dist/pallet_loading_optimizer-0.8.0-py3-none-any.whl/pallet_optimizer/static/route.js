(() => {
  'use strict';

  const $r = selector => document.querySelector(selector);
  const $$r = selector => [...document.querySelectorAll(selector)];
  const routeState = {
    depot: null,
    results: [],
    selected: 0,
    mapZoom: 1,
    mapPanX: 0,
    mapPanY: 0,
    drag: null,
  };

  const tableBody = $r('#route-jobs-table tbody');
  const mapCanvas = $r('#route-map');
  const mapContext = mapCanvas?.getContext('2d');
  const routeMessage = $r('#route-message');

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, char => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[char]));
  }

  function showMessage(message, error = false) {
    if (!routeMessage) return;
    routeMessage.textContent = message;
    routeMessage.classList.toggle('hidden', !message);
    routeMessage.classList.toggle('error', Boolean(error));
    routeMessage.classList.toggle('success', Boolean(message) && !error);
  }

  function fmt(value, digits = 1) {
    return Number(value || 0).toLocaleString('fr-FR', {
      maximumFractionDigits: digits,
      minimumFractionDigits: digits,
    });
  }

  function parseCoordinates(value) {
    const match = String(value || '').trim().match(/^\s*(-?\d{1,2}(?:[.,]\d+)?)\s*[,;]\s*(-?\d{1,3}(?:[.,]\d+)?)\s*$/);
    if (!match) return null;
    const lat = Number(match[1].replace(',', '.'));
    const lon = Number(match[2].replace(',', '.'));
    if (!Number.isFinite(lat) || !Number.isFinite(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) return null;
    return { lat, lon, display_name: `${lat.toFixed(6)}, ${lon.toFixed(6)}` };
  }

  async function geocodeAddress(address) {
    const manual = parseCoordinates(address);
    if (manual) return manual;
    const response = await fetch(`/api/route/geocode?q=${encodeURIComponent(address)}`);
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(body.detail || 'Adresse introuvable.');
    if (!body.results?.length) throw new Error(`Aucun résultat trouvé pour « ${address} ».`);
    return body.results[0];
  }

  function routeRowStatus(row) {
    const pickupReady = Number.isFinite(Number(row.dataset.pickupLat)) && Number.isFinite(Number(row.dataset.pickupLon));
    const deliveryReady = Number.isFinite(Number(row.dataset.deliveryLat)) && Number.isFinite(Number(row.dataset.deliveryLon));
    const status = row.querySelector('.route-row-status');
    status.className = 'route-row-status';
    if (pickupReady && deliveryReady) {
      status.classList.add('ready');
      status.textContent = 'Prête';
    } else if (pickupReady || deliveryReady) {
      status.classList.add('partial');
      status.textContent = 'Partielle';
    } else {
      status.textContent = 'À localiser';
    }
  }

  function invalidateCoordinates(row, type) {
    delete row.dataset[`${type}Lat`];
    delete row.dataset[`${type}Lon`];
    delete row.dataset[`${type}Label`];
    routeRowStatus(row);
  }

  function createRouteRow(data = {}) {
    const row = document.createElement('tr');
    row.dataset.id = data.id || `JOB-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    if (data.pickup?.lat != null) {
      row.dataset.pickupLat = data.pickup.lat;
      row.dataset.pickupLon = data.pickup.lon;
      row.dataset.pickupLabel = data.pickup.label || data.pickup.address || '';
    }
    if (data.delivery?.lat != null) {
      row.dataset.deliveryLat = data.delivery.lat;
      row.dataset.deliveryLon = data.delivery.lon;
      row.dataset.deliveryLabel = data.delivery.label || data.delivery.address || '';
    }
    row.innerHTML = `
      <td><input data-route="client" value="${escapeHtml(data.client || '')}" placeholder="Nom du client"></td>
      <td><input data-route="reference" value="${escapeHtml(data.reference || data.id || '')}" placeholder="Référence"></td>
      <td>
        <div class="route-job-address">
          <input data-route="pickup_address" value="${escapeHtml(data.pickup_address || data.pickup?.label || '')}" placeholder="Adresse d’enlèvement">
          <button type="button" class="secondary small route-locate" data-location="pickup">Localiser</button>
        </div>
      </td>
      <td>
        <div class="route-job-address">
          <input data-route="delivery_address" value="${escapeHtml(data.delivery_address || data.delivery?.label || '')}" placeholder="Adresse de livraison">
          <button type="button" class="secondary small route-locate" data-location="delivery">Localiser</button>
        </div>
      </td>
      <td><input data-route="weight_kg" type="number" min="0" step="1" value="${Number(data.weight_kg || 0)}"></td>
      <td><span class="route-row-status">À localiser</span></td>
      <td><button type="button" class="row-delete route-delete" title="Supprimer">×</button></td>`;

    row.querySelectorAll('input[data-route$="_address"]').forEach(input => {
      input.addEventListener('input', () => invalidateCoordinates(row, input.dataset.route.startsWith('pickup') ? 'pickup' : 'delivery'));
    });
    row.querySelectorAll('.route-locate').forEach(button => {
      button.addEventListener('click', () => locateRowAddress(row, button.dataset.location, button));
    });
    row.querySelector('.route-delete').addEventListener('click', () => row.remove());
    tableBody.append(row);
    routeRowStatus(row);
    return row;
  }

  async function locateRowAddress(row, type, button) {
    const input = row.querySelector(`[data-route="${type}_address"]`);
    const address = input.value.trim();
    if (!address) {
      showMessage(`Renseignez l’adresse ${type === 'pickup' ? 'd’enlèvement' : 'de livraison'}.`, true);
      return false;
    }
    const original = button.textContent;
    button.disabled = true;
    button.textContent = '…';
    try {
      const result = await geocodeAddress(address);
      row.dataset[`${type}Lat`] = result.lat;
      row.dataset[`${type}Lon`] = result.lon;
      row.dataset[`${type}Label`] = result.display_name;
      input.value = result.display_name;
      routeRowStatus(row);
      showMessage('Adresse localisée.');
      return true;
    } catch (error) {
      const status = row.querySelector('.route-row-status');
      status.className = 'route-row-status error';
      status.textContent = 'Erreur';
      showMessage(error.message || String(error), true);
      return false;
    } finally {
      button.disabled = false;
      button.textContent = original;
    }
  }

  async function locateDepot() {
    const address = $r('#route-depot-address').value.trim();
    const status = $r('#route-depot-status');
    if (!address) {
      showMessage('Renseignez le point de départ du camion.', true);
      return false;
    }
    const button = $r('#route-geocode-depot');
    const original = button.textContent;
    button.disabled = true;
    button.textContent = 'Localisation…';
    try {
      const result = await geocodeAddress(address);
      routeState.depot = { lat: result.lat, lon: result.lon, label: result.display_name };
      $r('#route-depot-address').value = result.display_name;
      status.textContent = `Localisé : ${result.lat.toFixed(5)}, ${result.lon.toFixed(5)}`;
      status.className = 'route-location-status located';
      showMessage('Point de départ localisé.');
      return true;
    } catch (error) {
      routeState.depot = null;
      status.textContent = error.message || String(error);
      status.className = 'route-location-status error';
      showMessage(status.textContent, true);
      return false;
    } finally {
      button.disabled = false;
      button.textContent = original;
    }
  }

  function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

  async function locateAll() {
    showMessage('Localisation des adresses en cours…');
    if (!routeState.depot && !(await locateDepot())) return false;
    const rows = [...tableBody.querySelectorAll('tr')];
    for (const row of rows) {
      for (const type of ['pickup', 'delivery']) {
        if (row.dataset[`${type}Lat`]) continue;
        const button = row.querySelector(`.route-locate[data-location="${type}"]`);
        const ok = await locateRowAddress(row, type, button);
        if (!ok) return false;
        // The public Nominatim service asks clients to avoid rapid bulk requests.
        await sleep(1050);
      }
    }
    showMessage('Toutes les adresses sont localisées.');
    return true;
  }

  function selectedVehicleCapacity() {
    const select = $r('#vehicle-id');
    const vehicles = window.PLO_VEHICLES || [];
    const vehicle = vehicles.find(item => item.model_id === select?.value) || vehicles[0];
    return Number(vehicle?.payload_kg || 24000);
  }

  function importClientsFromCargo() {
    const cargoRows = [...document.querySelectorAll('#cargo-table tbody tr')];
    if (!cargoRows.length) {
      showMessage('Aucune marchandise n’est présente dans l’onglet Données.', true);
      return;
    }
    const depotAddress = $r('#route-depot-address').value.trim();
    const grouped = new Map();
    cargoRows.forEach((cargo, index) => {
      const get = key => cargo.querySelector(`[data-k="${key}"]`);
      const reference = get('id')?.value.trim() || `REF-${index + 1}`;
      const destination = get('destination')?.value.trim() || `Client ${index + 1}`;
      const quantity = Number(get('quantity')?.value || 1);
      const weight = Number(get('weight')?.value || 0) * quantity;
      const key = destination.toLowerCase();
      if (!grouped.has(key)) {
        grouped.set(key, { client: destination, reference, weight_kg: weight });
      } else {
        const item = grouped.get(key);
        item.reference += `, ${reference}`;
        item.weight_kg += weight;
      }
    });
    tableBody.innerHTML = '';
    [...grouped.values()].forEach((item, index) => createRouteRow({
      id: `JOB-${String(index + 1).padStart(3, '0')}`,
      client: item.client,
      reference: item.reference,
      weight_kg: item.weight_kg,
      pickup_address: depotAddress,
      delivery_address: item.client,
    }));
    $r('#route-capacity').value = selectedVehicleCapacity();
    showMessage(`${grouped.size} client(s) récupéré(s). Complétez ou corrigez les adresses avant le calcul.`);
  }

  function rowPayload(row) {
    const field = name => row.querySelector(`[data-route="${name}"]`);
    const pickupLat = Number(row.dataset.pickupLat);
    const pickupLon = Number(row.dataset.pickupLon);
    const deliveryLat = Number(row.dataset.deliveryLat);
    const deliveryLon = Number(row.dataset.deliveryLon);
    if (![pickupLat, pickupLon, deliveryLat, deliveryLon].every(Number.isFinite)) {
      throw new Error(`La mission « ${field('client').value || field('reference').value || row.dataset.id} » n’est pas entièrement localisée.`);
    }
    return {
      id: row.dataset.id,
      client: field('client').value.trim() || row.dataset.id,
      reference: field('reference').value.trim() || row.dataset.id,
      weight_kg: Number(field('weight_kg').value || 0),
      pickup: {
        lat: pickupLat,
        lon: pickupLon,
        label: row.dataset.pickupLabel || field('pickup_address').value.trim(),
      },
      delivery: {
        lat: deliveryLat,
        lon: deliveryLon,
        label: row.dataset.deliveryLabel || field('delivery_address').value.trim(),
      },
    };
  }

  function buildPayload(method) {
    if (!routeState.depot) throw new Error('Le point de départ doit être localisé avant le calcul.');
    const rows = [...tableBody.querySelectorAll('tr')];
    if (!rows.length) throw new Error('Ajoutez au moins une mission.');
    return {
      method,
      depot: routeState.depot,
      jobs: rows.map(rowPayload),
      capacity_kg: Number($r('#route-capacity').value || 0),
      time_limit_s: Number($r('#route-time-limit').value || 5),
      seed: Number($r('#route-seed').value || 1),
      return_to_depot: $r('#route-return-depot').checked,
    };
  }

  function setCalculationButtons(disabled, label = null) {
    const buttons = [
      $r('#route-optimize-hgs'),
      $r('#route-optimize-alns'),
      $r('#route-compare'),
    ];
    buttons.forEach(button => {
      if (!button) return;
      if (!button.dataset.originalText) button.dataset.originalText = button.textContent;
      button.disabled = disabled;
      button.textContent = disabled && label ? label : button.dataset.originalText;
    });
  }

  async function runMethod(method) {
    showMessage('Calcul de la tournée en cours…');
    setCalculationButtons(true, 'Calcul en cours…');
    try {
      const payload = buildPayload(method);
      const response = await fetch('/api/route/optimize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.detail || 'Le calcul d’itinéraire a échoué.');
      routeState.results = [body];
      routeState.selected = 0;
      resetMapView();
      renderRouteResults();
      showMessage('Itinéraire calculé.');
    } catch (error) {
      showMessage(error.message || String(error), true);
    } finally {
      setCalculationButtons(false);
    }
  }

  async function compareMethods() {
    showMessage('Comparaison HGS / ALNS en cours…');
    setCalculationButtons(true, 'Comparaison…');
    try {
      const payload = buildPayload('hgs');
      const response = await fetch('/api/route/compare', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.detail || 'La comparaison a échoué.');
      routeState.results = body.results || [];
      routeState.selected = routeState.results.reduce((best, result, index, results) => (
        Number(result.total_distance_km) < Number(results[best].total_distance_km) ? index : best
      ), 0);
      resetMapView();
      renderRouteResults();
      showMessage('Les deux méthodes ont été comparées avec la même matrice routière.');
    } catch (error) {
      showMessage(error.message || String(error), true);
    } finally {
      setCalculationButtons(false);
    }
  }

  function methodHelpText(result) {
    return `${result.method_description}\n\nAdaptation AxioLoad : chaque mission forme un couple enlèvement → livraison avec contrainte de précédence. Les couples peuvent être entrelacés lorsque cela réduit le trajet, sous réserve de la capacité du camion.`;
  }

  function bindDynamicHelp(button, text) {
    const tooltip = document.createElement('div');
    tooltip.className = 'route-map-tooltip';
    tooltip.hidden = true;
    tooltip.textContent = text;
    document.body.append(tooltip);
    const show = () => {
      const rect = button.getBoundingClientRect();
      tooltip.hidden = false;
      tooltip.style.left = `${Math.min(window.innerWidth - tooltip.offsetWidth - 12, Math.max(12, rect.left - tooltip.offsetWidth / 2))}px`;
      tooltip.style.top = `${Math.min(window.innerHeight - tooltip.offsetHeight - 12, rect.bottom + 8)}px`;
    };
    const hide = () => { tooltip.hidden = true; };
    button.addEventListener('mouseenter', show);
    button.addEventListener('mouseleave', hide);
    button.addEventListener('focus', show);
    button.addEventListener('blur', hide);
    button.addEventListener('click', event => {
      event.stopPropagation();
      tooltip.hidden ? show() : hide();
    });
  }

  function renderRouteResults() {
    const container = $r('#route-results');
    if (!routeState.results.length) {
      container.classList.add('hidden');
      return;
    }
    container.classList.remove('hidden');
    const shortest = Math.min(...routeState.results.map(result => Number(result.total_distance_km)));
    const cards = $r('#route-result-cards');
    cards.innerHTML = '';
    routeState.results.forEach((result, index) => {
      const card = document.createElement('button');
      card.type = 'button';
      card.className = `route-result-card ${index === routeState.selected ? 'active' : ''} ${Math.abs(result.total_distance_km - shortest) < 1e-6 && routeState.results.length > 1 ? 'best' : ''}`;
      card.innerHTML = `
        <div class="route-result-method">
          <strong>${escapeHtml(result.method_name)}</strong>
          <button type="button" class="route-method-help" aria-label="Définition de ${escapeHtml(result.method_name)}">?</button>
        </div>
        <div class="route-result-metrics">
          <span class="route-result-metric"><span>Distance</span><strong>${fmt(result.total_distance_km, 1)} km</strong></span>
          <span class="route-result-metric"><span>Durée estimée</span><strong>${fmt(result.total_duration_min / 60, 1)} h</strong></span>
          <span class="route-result-metric"><span>Calcul</span><strong>${fmt(result.elapsed_seconds, 2)} s</strong></span>
        </div>
        <div class="route-result-engine">${escapeHtml(result.engine)} · ${Number(result.iterations || 0).toLocaleString('fr-FR')} itérations · ${escapeHtml(result.provider)}</div>
        ${(result.warnings || []).map(warning => `<div class="route-result-warning">${escapeHtml(warning)}</div>`).join('')}`;
      card.addEventListener('click', event => {
        if (event.target.closest('.route-method-help')) return;
        routeState.selected = index;
        resetMapView();
        renderRouteResults();
      });
      cards.append(card);
      bindDynamicHelp(card.querySelector('.route-method-help'), methodHelpText(result));
    });
    const selected = routeState.results[routeState.selected];
    $r('#route-source-note').textContent = `${selected.model_note} Source de distance : ${selected.provider}.`;
    $r('#route-map-title').textContent = selected.method_name;
    $r('#route-map-subtitle').textContent = `${fmt(selected.total_distance_km, 1)} km · ${fmt(selected.total_duration_min, 0)} min · ${selected.job_count} mission(s)`;
    renderStopList(selected);
    drawRouteMap();
  }

  function renderStopList(result) {
    const list = $r('#route-stop-list');
    list.innerHTML = result.stops.map((stop, index) => {
      const leg = index > 0 ? result.legs[index - 1] : null;
      const typeLabel = stop.type === 'pickup' ? 'Enlèvement' : stop.type === 'delivery' ? 'Livraison' : stop.type === 'return' ? 'Retour' : 'Départ';
      return `<article class="route-stop ${escapeHtml(stop.type)}">
        <span class="route-stop-number">${stop.sequence}</span>
        <div>
          <strong>${escapeHtml(typeLabel)}${stop.client ? ` · ${escapeHtml(stop.client)}` : ''}</strong>
          <small>${escapeHtml(stop.label || '')}</small>
          ${stop.reference ? `<small>Référence : ${escapeHtml(stop.reference)}</small>` : ''}
          ${stop.load_after_kg != null ? `<small>Charge après l’arrêt : ${fmt(stop.load_after_kg, 0)} kg</small>` : ''}
          ${leg ? `<div class="route-stop-leg">Depuis l’arrêt précédent : ${fmt(leg.distance_km, 1)} km · ${fmt(leg.duration_min, 0)} min</div>` : ''}
        </div>
      </article>`;
    }).join('');
  }

  function mapTheme() {
    const dark = document.documentElement.dataset.theme === 'dark';
    return dark ? {
      background: '#071D27', grid: 'rgba(114,181,199,.14)', gridStrong: 'rgba(114,181,199,.28)',
      route: '#32C6D4', shadow: 'rgba(0,0,0,.55)', text: '#ECF8FA', label: 'rgba(8,29,38,.94)', border: '#6EA9B9',
    } : {
      background: '#EDF7F9', grid: 'rgba(6,59,91,.10)', gridStrong: 'rgba(6,59,91,.22)',
      route: '#087FA2', shadow: 'rgba(5,46,70,.22)', text: '#063B5B', label: 'rgba(255,255,255,.96)', border: '#6E96A6',
    };
  }

  function resetMapView() {
    routeState.mapZoom = 1;
    routeState.mapPanX = 0;
    routeState.mapPanY = 0;
  }

  function drawRoundedLabel(ctx, text, x, y, theme, options = {}) {
    const font = options.font || '700 12px Segoe UI, Arial, sans-serif';
    ctx.save();
    ctx.font = font;
    ctx.textBaseline = 'middle';
    const width = ctx.measureText(text).width + 14;
    const height = 24;
    ctx.fillStyle = theme.label;
    ctx.strokeStyle = theme.border;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.roundRect(x - width / 2, y - height / 2, width, height, 7);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = theme.text;
    ctx.textAlign = 'center';
    ctx.fillText(text, x, y + 0.5);
    ctx.restore();
  }

  function drawRouteMap() {
    if (!mapContext || !routeState.results.length) return;
    const result = routeState.results[routeState.selected];
    const points = result.geometry?.length ? result.geometry : result.stops.map(stop => [stop.lat, stop.lon]);
    if (!points.length) return;
    const ctx = mapContext;
    const canvas = mapCanvas;
    const theme = mapTheme();
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = theme.background;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const lats = points.map(point => Number(point[0]));
    const lons = points.map(point => Number(point[1]));
    let minLat = Math.min(...lats); let maxLat = Math.max(...lats);
    let minLon = Math.min(...lons); let maxLon = Math.max(...lons);
    if (Math.abs(maxLat - minLat) < 0.002) { minLat -= 0.001; maxLat += 0.001; }
    if (Math.abs(maxLon - minLon) < 0.002) { minLon -= 0.001; maxLon += 0.001; }
    const padding = 58;
    const latMid = (minLat + maxLat) / 2;
    const lonScale = Math.max(0.25, Math.cos(latMid * Math.PI / 180));
    const projectedWidth = (maxLon - minLon) * lonScale;
    const projectedHeight = maxLat - minLat;
    const baseScale = Math.min((canvas.width - padding * 2) / projectedWidth, (canvas.height - padding * 2) / projectedHeight);
    const scale = baseScale * routeState.mapZoom;
    const centerLon = (minLon + maxLon) / 2;
    const centerLat = (minLat + maxLat) / 2;
    const project = ([lat, lon]) => [
      canvas.width / 2 + routeState.mapPanX + (lon - centerLon) * lonScale * scale,
      canvas.height / 2 + routeState.mapPanY - (lat - centerLat) * scale,
    ];

    const gridStepX = canvas.width / 10;
    const gridStepY = canvas.height / 8;
    for (let x = routeState.mapPanX % gridStepX; x <= canvas.width; x += gridStepX) {
      ctx.strokeStyle = Math.round(x / gridStepX) % 5 === 0 ? theme.gridStrong : theme.grid;
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke();
    }
    for (let y = routeState.mapPanY % gridStepY; y <= canvas.height; y += gridStepY) {
      ctx.strokeStyle = Math.round(y / gridStepY) % 4 === 0 ? theme.gridStrong : theme.grid;
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke();
    }

    const screenPoints = points.map(project);
    ctx.save();
    ctx.strokeStyle = theme.shadow;
    ctx.lineWidth = 9;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.beginPath();
    screenPoints.forEach((point, index) => index ? ctx.lineTo(...point) : ctx.moveTo(...point));
    ctx.stroke();
    ctx.strokeStyle = theme.route;
    ctx.lineWidth = 4;
    ctx.beginPath();
    screenPoints.forEach((point, index) => index ? ctx.lineTo(...point) : ctx.moveTo(...point));
    ctx.stroke();
    ctx.restore();

    result.stops.forEach((stop, index) => {
      const [x, y] = project([stop.lat, stop.lon]);
      const color = stop.type === 'pickup' ? '#F19B5C' : stop.type === 'delivery' ? '#16B8B0' : '#063B5B';
      ctx.save();
      ctx.fillStyle = color;
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(x, y, stop.type === 'start' || stop.type === 'return' ? 10 : 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '800 10px Segoe UI, Arial, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(String(stop.sequence), x, y + 0.5);
      ctx.restore();
      if (index === 0 || stop.type === 'delivery') {
        const label = index === 0 ? 'Départ' : stop.client;
        drawRoundedLabel(ctx, label, x, y - 22, theme);
      }
    });

    drawRoundedLabel(ctx, `${fmt(result.total_distance_km, 1)} km · ${fmt(result.total_duration_min, 0)} min`, canvas.width - 145, 30, theme, { font: '800 13px Segoe UI, Arial, sans-serif' });
  }

  function bindMapInteraction() {
    if (!mapCanvas) return;
    mapCanvas.addEventListener('pointerdown', event => {
      routeState.drag = { x: event.clientX, y: event.clientY, panX: routeState.mapPanX, panY: routeState.mapPanY };
      mapCanvas.setPointerCapture(event.pointerId);
    });
    mapCanvas.addEventListener('pointermove', event => {
      if (!routeState.drag) return;
      routeState.mapPanX = routeState.drag.panX + event.clientX - routeState.drag.x;
      routeState.mapPanY = routeState.drag.panY + event.clientY - routeState.drag.y;
      drawRouteMap();
    });
    mapCanvas.addEventListener('pointerup', () => { routeState.drag = null; });
    mapCanvas.addEventListener('pointercancel', () => { routeState.drag = null; });
    mapCanvas.addEventListener('wheel', event => {
      event.preventDefault();
      routeState.mapZoom = Math.max(0.65, Math.min(5, routeState.mapZoom * (event.deltaY > 0 ? 0.9 : 1.1)));
      drawRouteMap();
    }, { passive: false });
  }

  $r('#route-add-job')?.addEventListener('click', () => createRouteRow({ pickup_address: $r('#route-depot-address').value.trim() }));
  $r('#route-import-clients')?.addEventListener('click', importClientsFromCargo);
  $r('#route-geocode-depot')?.addEventListener('click', locateDepot);
  $r('#route-depot-address')?.addEventListener('input', () => {
    routeState.depot = null;
    const status = $r('#route-depot-status');
    status.textContent = 'Adresse modifiée : relancez la localisation.';
    status.className = 'route-location-status';
  });
  $r('#route-geocode-all')?.addEventListener('click', locateAll);
  $r('#route-optimize-hgs')?.addEventListener('click', () => runMethod('hgs'));
  $r('#route-optimize-alns')?.addEventListener('click', () => runMethod('alns'));
  $r('#route-compare')?.addEventListener('click', compareMethods);
  $r('#route-map-reset')?.addEventListener('click', () => { resetMapView(); drawRouteMap(); });

  const routeTab = $r('.tab[data-tab="route"]');
  routeTab?.addEventListener('click', () => {
    $r('#route-capacity').value = selectedVehicleCapacity();
    if (!tableBody.children.length) createRouteRow({ pickup_address: $r('#route-depot-address').value.trim() });
    setTimeout(drawRouteMap, 50);
  });

  new MutationObserver(() => drawRouteMap()).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
  bindMapInteraction();
  if (!tableBody.children.length) createRouteRow();
})();
